package pl.gruszczynski;

import pl.gruszczynski.classes.ArenaBase;
import pl.gruszczynski.classes.CharacterClass;
import pl.gruszczynski.classes.MonsterClass;
import pl.gruszczynski.classes.monsters.Klakier;
import pl.gruszczynski.classes.monsters.Gargamel;
import pl.gruszczynski.Menu;

public class Team {
    public CharacterClass[] teamMembers;
    public static int i = 0;
    private ArenaBase arena;

    public void setArena(ArenaBase arena) {
        this.arena = arena;
    }
    public Team(CharacterClass[] members) {
        int j = 0;
        teamMembers = new CharacterClass[members.length];
        for (CharacterClass member:members) {
            this.teamMembers[j] = member;
            j++;
        }

    }
    public CharacterClass[] getTeamMembers() {
        return teamMembers;
    }

    public void info(){
        for(CharacterClass teamMembers : teamMembers){
            teamMembers.info();
        }
    }

    public boolean enterArena(ArenaBase arena1) {
        return arena1.open(this);
    }

    public void start() {
        MonsterClass[] monsters = new MonsterClass[999];
        monsters[i] = new Klakier(this.teamMembers);
        MainWindow mw = new MainWindow(375, 438, this, monsters);
        this.spawnMonsters();
    }

    public void spawnMonsters() {
        Team thisTeam = this;
        int limit = Menu.ModeChosen=="How fast can you kill them?"? 12:3;
        if (MonsterClass.currentMonsters <= limit) {
            i++;
            GameField.monsters[i] = new Gargamel(this.teamMembers);
            new java.util.Timer().schedule(
                    new java.util.TimerTask() {
                        @Override
                        public void run() {
                            thisTeam.spawnMonsters();
                        }
                    }, Menu.ModeChosen=="Solo Deadmatch"? 3000:100
            );

        }
    }

    public ArenaBase getArena() {
        return arena;
    }
}
