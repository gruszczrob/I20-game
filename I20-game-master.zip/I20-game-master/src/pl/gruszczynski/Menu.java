package pl.gruszczynski;

import pl.gruszczynski.MenuWindow;
import pl.gruszczynski.Team;
import pl.gruszczynski.classes.ArenaBase;
import pl.gruszczynski.classes.CharacterClass;
import pl.gruszczynski.classes.arenas.Castle;
import pl.gruszczynski.classes.arenas.Syberia;
import pl.gruszczynski.classes.characters.Archer;
import pl.gruszczynski.classes.characters.Healer;
import pl.gruszczynski.classes.characters.Mage;
import pl.gruszczynski.classes.characters.Warrior;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;
import java.awt.event.KeyEvent;
import java.time.LocalTime;


public class Menu extends JPanel {

    private Team team;
    public String[] PlayersNumberSolo = {"1", "2", "3", "4"};
    private String[] PlayersNumberHowFast = {"1"};
    private String[] mapNames = {"winter", "castle"};
    private String[] Modes = {"Solo Deadmatch", "How fast can you kill them?"};
    private String[] Classes = {"Archer", "Healer", "Mage", "Warrior"};
    public MenuWindow frame;
    public static String ModeChosen;
    public String TeamChosen;
    public Integer TeamChosenInt;
    public String MapChosen;
    public String ClasseChosen;
    public JComboBox TeamChose;
    public Team teamfin;
    public Integer jetplay = 0;
    public static LocalTime stoperStart;
    int[] x = {0, 0, 320, 320};
    int[] y = {0, 320, 0, 320};
    int[] left = {KeyEvent.VK_A, KeyEvent.VK_H, KeyEvent.VK_LEFT, KeyEvent.VK_NUMPAD1};
    int[] right = {KeyEvent.VK_D, KeyEvent.VK_K, KeyEvent.VK_RIGHT, KeyEvent.VK_NUMPAD3};
    int[] up = {KeyEvent.VK_W, KeyEvent.VK_U, KeyEvent.VK_UP, KeyEvent.VK_NUMPAD5};
    int[] down = {KeyEvent.VK_S, KeyEvent.VK_J, KeyEvent.VK_DOWN, KeyEvent.VK_NUMPAD2};
    int[] lattac = {KeyEvent.VK_Q, KeyEvent.VK_Y, KeyEvent.VK_DELETE, KeyEvent.VK_NUMPAD4};
    int[] rattac = {KeyEvent.VK_E, KeyEvent.VK_I, KeyEvent.VK_PAGE_DOWN, KeyEvent.VK_NUMPAD6};
    int[] ability = {KeyEvent.VK_R, KeyEvent.VK_O, KeyEvent.VK_SHIFT, KeyEvent.VK_NUMPAD9};



    int i = 0;

    public Menu(MenuWindow frame) {
        this.frame = frame;
        setFocusable(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        //Menu
        g.drawString("MENU", 50, 10);
        //Select map
        g.drawString("Map: ", 20, 50);
        final JComboBox mapchose = new JComboBox(mapNames);
        mapchose.setSelectedIndex(0);
        mapchose.setBounds(75, 40, 150, 20);

        //select mode
        g.drawString("Mode: ", 20, 100);
        final JComboBox Modechose = new JComboBox(Modes);
        Modechose.setSelectedIndex(0);
        Modechose.setBounds(75, 100, 150, 20);

        JButton Modeb = new JButton("Submit your choice");
        Modeb.setBounds(75, 130, 150, 20);
        frame.add(Modeb);
        Modeb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.remove(Modeb);
                SwingUtilities.updateComponentTreeUI(frame);
                MapChosen = (String) mapchose.getItemAt(mapchose.getSelectedIndex());
                ModeChosen = (String) Modechose.getItemAt(Modechose.getSelectedIndex());
                System.out.println(ModeChosen);


                //select count of players in game
                g.drawString("Players: ", 20, 170);
                final JComboBox TeamChose = new JComboBox((ModeChosen == "Solo Deadmatch") ? PlayersNumberSolo : PlayersNumberHowFast);
                frame.add(TeamChose);
                TeamChose.setBounds(75, 170, 150, 20);
                JButton Teamb = new JButton("Submit your choice");
                Teamb.setBounds(75, 210, 150, 20);
                frame.add(Teamb);

                Teamb.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        TeamChosen = (String) TeamChose.getItemAt(TeamChose.getSelectedIndex());

                        frame.remove(Teamb);
                        SwingUtilities.updateComponentTreeUI(frame);
                        i = 0;
                        TeamChosenInt = Integer.parseInt(TeamChosen);
                        CharacterClass[] characters = new CharacterClass[TeamChosenInt];
                        //ALL OF THE PLAYERS WRITE THEIR NICKNAME AND SELECT CLASSES
                        while (TeamChosenInt > i) {
                            g.drawString("Player " + (i + 1) + ". ", 20, 240 + i * 30);

                            final JTextField Player = new JTextField("Player " + (i + 1) + ".");
                            Player.setBounds(75, 240 + i * 30, 150, 20);
                            frame.add(Player);
                            g.drawString("Class: ", 250, 240 + i * 30);

                            final JComboBox ClasseChoice = new JComboBox(Classes);
                            frame.add(ClasseChoice);
                            ClasseChoice.setSelectedIndex(0);
                            ClasseChoice.setBounds(300, 240 + i * 30, 100, 20);
                            frame.add(ClasseChoice);
                            JButton Submitt = new JButton("Submit your choice");
                            Submitt.setBounds(450, 240 + i * 30, 150, 20);
                            frame.add(Submitt);

                            Submitt.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent e) {
                                    ClasseChosen = (String) ClasseChoice.getItemAt(ClasseChoice.getSelectedIndex());
                                    String play = Player.getText();
                                    switch (ClasseChosen) {
                                        case "Warrior":
                                            System.out.println(play + " - Warrior");
                                            Warrior warrior = new Warrior(play, x[jetplay], y[jetplay], left[jetplay], right[jetplay], up[jetplay], down[jetplay], lattac[jetplay], rattac[jetplay], 0);
                                            characters[jetplay] = warrior;
                                            jetplay++;
                                            frame.remove(Submitt);
                                            SwingUtilities.updateComponentTreeUI(frame);
                                            break;

                                        case "Mage":
                                            System.out.println(play + " - Mage");
                                            Mage mage = new Mage(play, x[jetplay], y[jetplay], left[jetplay], right[jetplay], up[jetplay], down[jetplay], lattac[jetplay], rattac[jetplay], 0);
                                            characters[jetplay] = mage;
                                            jetplay++;
                                            frame.remove(Submitt);
                                            SwingUtilities.updateComponentTreeUI(frame);
                                            break;

                                        case "Archer":
                                            System.out.println(play + " - Archer");
                                            Archer archer = new Archer(play, x[jetplay], y[jetplay], left[jetplay], right[jetplay], up[jetplay], down[jetplay], lattac[jetplay], rattac[jetplay], 0);
                                            characters[jetplay] = archer;
                                            jetplay++;
                                            frame.remove(Submitt);
                                            SwingUtilities.updateComponentTreeUI(frame);
                                            break;

                                        case "Healer":
                                            System.out.println(play + " - Healer");
                                            Healer healer = new Healer(play, x[jetplay], y[jetplay], left[jetplay], right[jetplay], up[jetplay], down[jetplay], lattac[jetplay], rattac[jetplay], ability[jetplay]);
                                            characters[jetplay] = healer;
                                            jetplay++;
                                            frame.remove(Submitt);
                                            SwingUtilities.updateComponentTreeUI(frame);
                                            break;
                                    }
                                }
                            });
                            i++;
                        }


                        //Start
                        JButton start = new JButton("Start");
                        start.setBounds(50, 270 + (i * 30), 100, 20);
                        frame.add(start);
                        start.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                Team team = new Team (characters);
                                stoperStart = java.time.LocalTime.now();
                                ArenaBase map = null;
                                switch (MapChosen){
                                    case "winter":
                                        map = new Syberia();
                                        break;
                                    case "castle":
                                        map = new Castle();
                                        break;
                                }
                                if (team.enterArena(map)) {
                                    team.setArena(map);
                                    team.start();
                                    for (int[] wall : map.getWallLocation()) {
                                        CharacterClass.occupiedCells[wall[0]][wall[1]] = 5;
                                    }
                                } else {
                                    System.out.println("Game over");
                                }
                                frame.dispose();
                            }
                        });
                    }
                });
            }
        });

        frame.add(mapchose);
        frame.add(Modechose);


        frame.setLayout(null);
        frame.setVisible(true);

    }
}



