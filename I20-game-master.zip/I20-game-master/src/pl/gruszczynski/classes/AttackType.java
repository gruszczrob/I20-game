package pl.gruszczynski.classes;

public enum AttackType {
    PHYSICAL, MAGICAL, FIRE, AIR, EARTH, WATER, MAGICAL_RANGED, PHYSICAL_RANGED;
}
