package pl.gruszczynski.classes.monsters;

import pl.gruszczynski.classes.CharacterClass;
import pl.gruszczynski.classes.MonsterClass;

import javax.swing.*;

public class Klakier extends MonsterClass {

    public Klakier(CharacterClass[] players) {
        super(players);
        this.speed = 1500;
        this.attackAmount = 100;
        this.health = 150;
        this.maxHealth = 150;
        this.image = new ImageIcon("16.png").getImage();
    }
}
