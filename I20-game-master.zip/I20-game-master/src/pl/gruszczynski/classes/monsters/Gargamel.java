package pl.gruszczynski.classes.monsters;

import pl.gruszczynski.classes.CharacterClass;
import pl.gruszczynski.classes.MonsterClass;

import javax.swing.*;

public class Gargamel extends MonsterClass {

    public Gargamel(CharacterClass[] players) {
        super(players);
        this.speed = 2500;
        this.attackAmount = 100;
        this.health = 400;
        this.maxHealth = 400;
        this.image = new ImageIcon("15.png").getImage();
    }
}
