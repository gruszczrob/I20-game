package pl.gruszczynski.classes.arenas;

import pl.gruszczynski.Team;

public interface BaseArena {
    boolean open(Team team);
}
