package pl.gruszczynski;

public class Main {

    public static void main(String[] args) {
        MenuWindow Menu = new MenuWindow(800, 800);

    }
}
